import React from 'react';

function AnimatronicCard({ character }) {
  const { fnafWorld } = character;

  return (
    <div style={{
      border: '2px solid #333',
      padding: '15px',
      background: '#151515',
      borderRadius: '4px',
      textAlign: 'left'
    }}>
      <h3 style={{ color: '#ff5555', margin: '0 0 4px 0' }}>{character.name}</h3>
      <p style={{ color: '#888', margin: '0 0 14px 0' }}>{fnafWorld.characterName}</p>

      <h4 style={{ color: '#00cccc', margin: '0 0 6px 0' }}>Roles</h4>
      <p style={{ color: '#ddd', margin: '0 0 14px 0' }}>
        {fnafWorld.roles.map((role) => role.label).join(' · ')}
      </p>

      <h4 style={{ color: '#00cccc', margin: '0 0 6px 0' }}>Moves</h4>
      <ul style={{ color: '#bbb', margin: '0 0 16px 0', paddingLeft: '20px' }}>
        {fnafWorld.moves.map((move) => (
          <li key={move.name} style={{ marginBottom: '6px' }}>
            <strong style={{ color: '#eee' }}>{move.name}</strong>: {move.effect}
          </li>
        ))}
      </ul>

    </div>
  );
}

export default AnimatronicCard;
