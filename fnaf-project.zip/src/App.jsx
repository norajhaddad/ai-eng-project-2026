import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import fnafData from './fnaf-data.json';
import AnimatronicCard from './AnimatronicCard';

function CharacterIcon({ character, size = 38 }) {
  const initials = character.name.split(' ').map((part) => part.charAt(0)).join('').slice(0, 2);

  return (
    <span
      aria-hidden="true"
      style={{
        width: size,
        height: size,
        minWidth: size,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        border: '1px solid #00aaaa',
        borderRadius: '50%',
        background: '#102323',
        color: '#8fffff',
        fontWeight: 'bold',
        lineHeight: 1
      }}
    >
      {initials}
    </span>
  );
}

function getRoleDescription(character) {
  return character.fnafWorld.roles.map((role) => role.label).join(' · ');
}

function DexView() {
  return (
    <main>
      <h2>FNaF World Character Gallery</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 270px), 1fr))', gap: '15px' }}>
        {fnafData.map((character) => (
          <AnimatronicCard
            key={character.id}
            character={character}
          />
        ))}
      </div>
    </main>
  );
}

function TeamBuilderView({ parties, onCreateParty }) {
  const [isSelecting, setIsSelecting] = useState(false);
  const [selectedIds, setSelectedIds] = useState([]);

  const toggleCharacter = (characterId) => {
    setSelectedIds((current) => {
      if (current.includes(characterId)) {
        return current.filter((id) => id !== characterId);
      }
      if (current.length === 4) {
        return current;
      }
      return [...current, characterId];
    });
  };

  const clearSelection = () => setSelectedIds([]);

  const createParty = () => {
    if (selectedIds.length !== 4) {
      return;
    }
    onCreateParty(selectedIds);
    setSelectedIds([]);
    setIsSelecting(false);
  };

  if (isSelecting) {
    return (
      <main style={{ minHeight: '65vh', display: 'flex', flexDirection: 'column' }}>
        <div>
          <h2>Select Party Members</h2>
          <p style={{ color: '#aaa' }}>{selectedIds.length} / 4 selected</p>
          <div style={{ display: 'grid', gap: '8px' }}>
            {fnafData.map((character) => {
              const isSelected = selectedIds.includes(character.id);
              const isAtLimit = selectedIds.length === 4 && !isSelected;
              return (
                <button
                  key={character.id}
                  type="button"
                  aria-pressed={isSelected}
                  disabled={isAtLimit}
                  onClick={() => toggleCharacter(character.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    width: '100%',
                    padding: '12px',
                    textAlign: 'left',
                    border: `1px solid ${isSelected ? '#00ffff' : '#444'}`,
                    background: isSelected ? '#123030' : '#151515',
                    color: isAtLimit ? '#666' : '#fff',
                    cursor: isAtLimit ? 'not-allowed' : 'pointer'
                  }}
                >
                  <CharacterIcon character={character} size={32} />
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <strong style={{ display: 'block' }}>{character.name}</strong>
                    <span style={{ color: '#aaa', fontSize: '0.9rem', overflowWrap: 'anywhere' }}>
                      {getRoleDescription(character)}
                    </span>
                  </span>
                  <span style={{ color: isSelected ? '#00ffff' : '#777', whiteSpace: 'nowrap' }}>
                    {isSelected ? 'SELECTED' : ''}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px', marginTop: 'auto', paddingTop: '28px' }}>
          <button
            type="button"
            onClick={clearSelection}
            style={{ padding: '10px 18px', background: '#222', color: '#fff', border: '1px solid #666', cursor: 'pointer' }}
          >
            CLEAR
          </button>
          <button
            type="button"
            onClick={createParty}
            disabled={selectedIds.length !== 4}
            style={{
              padding: '10px 18px',
              background: selectedIds.length === 4 ? '#063b3b' : '#222',
              color: selectedIds.length === 4 ? '#00ffff' : '#777',
              border: `1px solid ${selectedIds.length === 4 ? '#00ffff' : '#444'}`,
              cursor: selectedIds.length === 4 ? 'pointer' : 'not-allowed'
            }}
          >
            CREATE
          </button>
        </div>
      </main>
    );
  }

  return (
    <main>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '16px', flexWrap: 'wrap', marginBottom: '24px' }}>
        <h2 style={{ margin: 0 }}>Team Builder</h2>
        <button
          type="button"
          onClick={() => setIsSelecting(true)}
          style={{ padding: '10px 16px', background: '#063b3b', color: '#00ffff', border: '1px solid #00aaaa', cursor: 'pointer' }}
        >
          Create New Party
        </button>
      </div>
      {parties.length === 0 ? (
        <p style={{ color: '#888' }}>No parties created.</p>
      ) : (
        <div>
          {parties.map((party, index) => (
            <div
              key={party.id}
              style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '10px', padding: '14px 0', borderBottom: '1px solid #333' }}
            >
              <strong style={{ minWidth: '90px' }}>Party {index + 1}</strong>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                {party.memberIds.map((characterId) => {
                  const character = fnafData.find((item) => item.id === characterId);
                  return character ? (
                    <span key={character.id} title={character.name}>
                      <CharacterIcon character={character} size={32} />
                    </span>
                  ) : null;
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}

function App() {
  const [parties, setParties] = useState([]);

  const handleCreateParty = (memberIds) => {
    setParties((current) => [...current, { id: current.length + 1, memberIds: [...memberIds] }]);
  };

  return (
    <BrowserRouter>
      <div style={{ boxSizing: 'border-box', padding: 'clamp(16px, 4vw, 30px)', background: '#0a0a0a', color: '#fff', minHeight: '100vh', fontFamily: 'monospace' }}>
        <nav style={{ marginBottom: '30px', display: 'flex', flexWrap: 'wrap', gap: '12px 20px', fontSize: '1.1rem' }}>
          <Link to="/" style={{ color: '#00ffff', textDecoration: 'none', fontWeight: 'bold' }}>[ Character Gallery ]</Link>
          <Link to="/team-builder" style={{ color: '#00ffff', textDecoration: 'none', fontWeight: 'bold' }}>[ Team Builder ]</Link>
        </nav>
        <Routes>
          <Route path="/" element={<DexView />} />
          <Route
            path="/team-builder"
            element={<TeamBuilderView parties={parties} onCreateParty={handleCreateParty} />}
          />
          <Route path="*" element={<DexView />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
